<template>
    <Page>
        <ActionBar>
            <Label text="Vue.js Demo"/>
        </ActionBar>

        <Drawer ref="drawer" leftDrawerMode="slide">
            <StackLayout ~leftDrawer width="300" backgroundColor="blue">
                <StackLayout backgroundColor="green" margin="25" height="100">
                    <Label text="StackLayout (iOS left margin doesn't work)" />
                </StackLayout>
                <GridLayout backgroundColor="orange" margin="25" height="100">
                    <Label text="GridLayout (iOS left margin doesn't work)" />
                </GridLayout>
                <Label backgroundColor="red" margin="25" height="100" text="Just a Label (iOS left margin works!)" />
                <!-- <StackLayout marginLeft="50">
                    <StackLayout backgroundColor="#eeeeee" padding="20" marginLeft="50">
                        <GridLayout columns="80, *" height="100">
                            <StackLayout col="0" backgroundColor="#42b883" borderRadius="40" height="80" verticalAlignment="middle">
                                <Label verticalAlignment="middle" horizontalAlignment="center" text="JS" fontSize="25" color="white" />
                            </StackLayout>
                        </GridLayout>
                        <StackLayout>
                            <Label text="John Smith" fontWeight="bold" />
                            <Label text="john.smith@gmail.com" />
                        </StackLayout>
                    </StackLayout>
                    <StackLayout>
                        <Button text="Close Drawer" @tap="onCloseDrawer" class="button" />
                    </StackLayout>
                </StackLayout>
                <StackLayout verticalAlignment="bottom" marginLeft="25">
                    <Label text="This is a footer"  marginLeft="25" />
                </StackLayout> -->
            </StackLayout>
            <StackLayout ~mainContent backgroundColor="white">
                <!-- <StackLayout margin="25">
                    <Label text="John Smith" />
                    <Label text="john.smith@gmail.com" />
                </StackLayout>
                <Label text="Main Content" />    
                <Label text="Main Content" />    
                <Button text="Open Drawer" @tap="onOpenDrawer" class="button" /> -->
            </StackLayout>
        </Drawer> 
    </Page>
</template>

<script lang="typescript">
  export default {
    computed: {
      message() {
        return "Blank {N}-Vue app";
      }
    },
    methods: {
        onOpenDrawer() {
            this.$refs["drawer"].open("left");
        },
        onCloseDrawer() {
            this.$refs["drawer"].close("left");
        }
    }
  };
</script>

<style scoped lang="scss">
    @import '~@nativescript/theme/scss/variables/blue';

    ActionBar {
        background-color: #42b883;
    }

    .button {
        background-color: transparent;
        border-color: transparent;
        z-index:0;
        border-width: 1;
    }
</style>
